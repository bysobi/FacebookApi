//
//  AppDelegate.h
//  Logo
//
//  Created by Admin on 17.11.14.
//  Copyright (c) 2014 Petrenko Pavel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

